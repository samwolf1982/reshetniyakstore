<?php
// Heading
$_['heading_title'] = 'Featured Categories Products Tabs Slider';

// Text
$_['text_reviews']          = '%s reviews';
$_['text_sale']      = 'Sale';
$_['text_new']      = 'New';
$_['text_empty_categories'] = 'There is no featured categories';
$_['text_empty_products'] 	= 'There is no products in this category';