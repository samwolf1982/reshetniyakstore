<?php
// Heading
$_['heading_title'] = 'Featured Categories';
$_['text_readmore'] = 'see more';