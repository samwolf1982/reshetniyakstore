<?php
// Heading
$_['heading_title']    = '<b><i>OC Category Thumbnail</i></b>';
$_['page_title']       = 'OC Category Thumbnail';

// Text
$_['text_extension']      = 'Extensions';
$_['text_message']     = 'You have installed OC Category Thumbnail Module';